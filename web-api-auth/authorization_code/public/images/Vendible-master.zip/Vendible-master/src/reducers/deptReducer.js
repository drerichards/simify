export default function () {
    return [{
        dept: 'Apparel',
        img: 'http://res.cloudinary.com/andrerichards/image/upload/v1506070591/dept/Sneakers-2-256.png'
    }, {
        dept: 'Electronics',
        img: 'http://res.cloudinary.com/andrerichards/image/upload/v1506069998/dept/Online-Shopping-256.png'
    }, {
        dept: 'Homegoods',
        img: 'http://res.cloudinary.com/andrerichards/image/upload/v1506070084/dept/Chair-4-256.png'
    }]
}